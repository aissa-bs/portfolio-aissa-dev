import { Home, User, Code2, Briefcase, Mail, FileText } from 'lucide-react';
import { NavItem, Project, SkillCategory, EducationItem, ExperienceItem } from './types';

export const NAV_ITEMS: NavItem[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'about', label: 'About Me', icon: User },
  { id: 'skills', label: 'Skills', icon: Code2 },
  { id: 'projects', label: 'Projects', icon: Briefcase },
  { id: 'cv', label: 'Resume', icon: FileText },
  { id: 'contact', label: 'Contact', icon: Mail },
];

export const PROJECTS: Project[] = [
  {
    id: 1,
    title: "Neon Nexus Dashboard",
    shortDesc: "Real-time crypto analytics platform.",
    fullDesc: "A high-performance analytics dashboard for cryptocurrency markets featuring real-time WebSocket data updates, interactive D3.js charts, and a customizable widget system. Built to handle high-frequency data updates with minimal latency.",
    technologies: ["React", "TypeScript", "D3.js", "WebSockets", "Node.js"],
    imageUrl: "https://picsum.photos/id/48/600/400",
    demoUrl: "#",
    repoUrl: "#"
  },
  {
    id: 2,
    title: "Aether Cloud",
    shortDesc: "Decentralized file storage solution.",
    fullDesc: "A secure, encrypted file storage system utilizing IPFS. Users can drag and drop files to encrypt them client-side before uploading. Features include file sharing, version history, and team collaboration folders.",
    technologies: ["Next.js", "IPFS", "Solidity", "Tailwind CSS"],
    imageUrl: "https://picsum.photos/id/20/600/400",
    demoUrl: "#",
    repoUrl: "#"
  },
  {
    id: 3,
    title: "Zenith Task AI",
    shortDesc: "AI-powered productivity manager.",
    fullDesc: "An intelligent task manager that uses Gemini API to categorize tasks, suggest deadlines, and break down complex goals into actionable steps. Includes a Pomodoro timer and distraction blocking.",
    technologies: ["React", "Python", "FastAPI", "Gemini API"],
    imageUrl: "https://picsum.photos/id/180/600/400",
    demoUrl: "#",
    repoUrl: "#"
  },
  {
    id: 4,
    title: "Voxel Verse",
    shortDesc: "3D Social creative sandbox.",
    fullDesc: "A browser-based 3D world where users can build structures using voxel blocks together in real-time. Leverages Three.js for rendering and Socket.io for multiplayer synchronization.",
    technologies: ["Three.js", "React-Three-Fiber", "Socket.io", "Express"],
    imageUrl: "https://picsum.photos/id/132/600/400",
    demoUrl: "#",
    repoUrl: "#"
  }
];

export const SKILL_CATEGORIES: SkillCategory[] = [
  {
    id: 'frontend',
    title: 'Frontend',
    skills: [
      { name: 'Flutter', level: 90, slug: 'flutter' },
      { name: 'React', level: 95, slug: 'react' },
      { name: 'HTML', level: 98, slug: 'html5' },
      { name: 'CSS', level: 95, slug: 'css3' },
      { name: 'TypeScript', level: 90, slug: 'typescript' },
      { name: 'JavaScript', level: 95, slug: 'javascript' },
    ]
  },
  {
    id: 'backend',
    title: 'Backend',
    skills: [
      { name: 'Node.js', level: 88, slug: 'nodedotjs' },
      { name: 'Python', level: 80, slug: 'python' },
      { name: 'PostgreSQL', level: 85, slug: 'postgresql' },
      { name: 'GraphQL', level: 75, slug: 'graphql' },
      { name: 'Firebase', level: 85, slug: 'firebase' },
    ]
  },
  {
    id: 'tools',
    title: 'DevOps & Tools',
    skills: [
      { name: 'Docker', level: 80, slug: 'docker' },
      { name: 'Jest', level: 75, slug: 'jest' },
      { name: 'Git', level: 95, slug: 'git' },
      { name: 'Terminal', level: 85, slug: 'gnubash' },
      { name: 'Play Console', level: 80, slug: 'googleplay' },
      { name: 'App Store', level: 80, slug: 'apple' },
      { name: 'Stripe', level: 75, slug: 'stripe' },
      { name: 'Linux', level: 70, slug: 'linux' },
    ]
  },
  {
    id: 'design',
    title: 'Graphic Design',
    skills: [
      { name: 'Canva', level: 90, slug: 'canva' },
      { name: 'Photoshop', level: 85, slug: 'adobephotoshop' },
      { name: 'Illustrator', level: 80, slug: 'adobeillustrator' },
    ]
  }
];

export const EDUCATION_HISTORY: EducationItem[] = [
  {
    id: 1,
    year: "2024",
    degree: "Master's Degree",
    institution: "Hassiba Benbouali University of Chlef",
    details: "Specialization in Advanced Information Systems Engineering. Graduated with Excellent mention."
  },
  {
    id: 2,
    year: "2022",
    degree: "Bachelor's Degree",
    institution: "Hassiba Benbouali University of Chlef",
    details: "Computer Science. Graduated with Good mention."
  },
  {
    id: 3,
    year: "2019",
    degree: "Baccalaureate (2nd Year)",
    institution: "High School",
    details: "Secondary Education completion."
  },
  {
    id: 4,
    year: "2018",
    degree: "Baccalaureate (1st Year)",
    institution: "High School",
    details: "Foundational secondary studies."
  }
];

export const EXPERIENCE_HISTORY: ExperienceItem[] = [
  {
    id: 1,
    period: "Present",
    role: "Full Stack Developer",
    company: "Omran Software",
    description: "Developing scalable web applications, managing end-to-end development lifecycles, and collaborating with cross-functional teams to deliver high-quality software solutions."
  },
  {
    id: 2,
    period: "2022 - 2023",
    role: "Freelance Web Developer",
    company: "Self-Employed",
    description: "Built custom websites and e-commerce solutions for various international clients using React and Node.js."
  }
];