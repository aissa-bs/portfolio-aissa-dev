import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, Linkedin, Github, Send } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [formState, setFormState] = useState<'idle' | 'sending' | 'sent'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormState('sending');
    // Simulate API
    setTimeout(() => {
        setFormState('sent');
        setTimeout(() => setFormState('idle'), 3000);
    }, 1500);
  };

  return (
    <div className="grid md:grid-cols-2 gap-8 h-full">
      {/* Contact Info */}
      <div className="flex flex-col justify-center space-y-6">
        <h3 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400">
            Let's create something amazing together.
        </h3>
        <p className="text-zinc-600 dark:text-zinc-400">
            Available for freelance opportunities and full-time roles. Drop me a line!
        </p>

        <div className="space-y-4">
            <SocialLink icon={Mail} text="hello@alex.dev" href="mailto:hello@alex.dev" />
            <SocialLink icon={Phone} text="+1 (555) 123-4567" href="tel:+15551234567" />
            <SocialLink icon={Linkedin} text="linkedin.com/in/alex" href="#" />
            <SocialLink icon={Github} text="github.com/alexdev" href="#" />
        </div>
      </div>

      {/* Form */}
      <div className="bg-white/50 dark:bg-white/5 p-6 rounded-2xl border border-black/5 dark:border-white/5 shadow-sm">
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label className="block text-xs font-medium text-zinc-500 dark:text-zinc-400 mb-1 uppercase tracking-wide">Name</label>
                <input 
                    type="text" 
                    required
                    className="w-full bg-white dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-700 rounded-lg px-4 py-3 text-zinc-900 dark:text-white focus:outline-none focus:border-blue-500 transition-colors placeholder-zinc-400"
                    placeholder="John Doe"
                />
            </div>
            <div>
                <label className="block text-xs font-medium text-zinc-500 dark:text-zinc-400 mb-1 uppercase tracking-wide">Email</label>
                <input 
                    type="email" 
                    required
                    className="w-full bg-white dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-700 rounded-lg px-4 py-3 text-zinc-900 dark:text-white focus:outline-none focus:border-blue-500 transition-colors placeholder-zinc-400"
                    placeholder="john@example.com"
                />
            </div>
            <div>
                <label className="block text-xs font-medium text-zinc-500 dark:text-zinc-400 mb-1 uppercase tracking-wide">Message</label>
                <textarea 
                    rows={4}
                    required
                    className="w-full bg-white dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-700 rounded-lg px-4 py-3 text-zinc-900 dark:text-white focus:outline-none focus:border-blue-500 transition-colors resize-none placeholder-zinc-400"
                    placeholder="Tell me about your project..."
                />
            </div>

            <button 
                type="submit"
                disabled={formState !== 'idle'}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-semibold py-3 rounded-lg transition-all transform active:scale-95 flex items-center justify-center gap-2 shadow-lg shadow-blue-900/20"
            >
                {formState === 'idle' && <><Send size={18} /> Send Message</>}
                {formState === 'sending' && <span className="animate-pulse">Sending...</span>}
                {formState === 'sent' && <span className="text-green-300">Message Sent!</span>}
            </button>
        </form>
      </div>
    </div>
  );
};

const SocialLink = ({ icon: Icon, text, href }: { icon: any, text: string, href: string }) => (
    <a 
        href={href}
        className="flex items-center gap-3 p-3 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition-colors group"
    >
        <div className="w-10 h-10 rounded-full bg-black/5 dark:bg-white/5 flex items-center justify-center group-hover:bg-blue-500/20 group-hover:text-blue-600 dark:group-hover:text-blue-400 text-zinc-600 dark:text-zinc-400 transition-colors">
            <Icon size={20} />
        </div>
        <span className="text-zinc-600 dark:text-zinc-300 group-hover:text-zinc-900 dark:group-hover:text-white transition-colors">{text}</span>
    </a>
);